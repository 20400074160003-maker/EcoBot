EcoBot Upgraded – Educational Environmental Chatbot

FILES
- app.py: Streamlit app with curated environmental topic guides, topic matching, source links, a topic library and a quiz.
- requirements.txt: Python dependency.

IMPORTANT
- This is NOT a generative AI chatbot.
- It does not use an AI API, account, or API key.
- Answers come from a prepared educational knowledge base.
- If it cannot confidently match a question, it says it does not have a verified answer rather than guessing.
- Source links are provided for further reading. Check the original sources for the newest figures and local guidance.

UPDATE YOUR EXISTING STREAMLIT APP
1. Open your EcoBot repository on GitHub.
2. Open app.py, choose the pencil/Edit button, replace the entire old code with the new app.py contents, and commit the change.
   Alternatively, use Add file > Upload files and upload the new app.py, replacing the old file.
3. Upload/keep requirements.txt in the repository root.
4. Streamlit Community Cloud normally detects the GitHub commit and updates the app automatically. If it does not, open Manage app and reboot it.
5. Test with the sample questions and compare answers with the source links.

The repository root should contain:
- app.py
- requirements.txt
