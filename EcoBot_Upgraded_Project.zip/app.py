import re
import streamlit as st

st.set_page_config(
    page_title="EcoBot | Environmental Learning",
    page_icon="🌿",
    layout="centered",
    initial_sidebar_state="collapsed",
)

st.markdown("""
<style>
:root { --green:#146c43; }
.block-container {max-width: 900px; padding-top: 1.5rem; padding-bottom: 3rem;}
.hero {
  background: linear-gradient(120deg,#0d4f36,#178354);
  color:white; padding:28px 26px; border-radius:22px; margin-bottom:18px;
}
.hero h1 {font-size:2.45rem; margin:0; color:white;}
.hero p {font-size:1.05rem; margin:.5rem 0 0; color:#e3f6eb;}
.small-note {color:#557064; font-size:.9rem;}
.source-card {background:#f0f7f2; padding:12px 15px; border-radius:12px; margin:8px 0;}
div.stButton > button {border-radius:12px;}
</style>
""", unsafe_allow_html=True)

# Curated educational knowledge base. Each topic has a focused answer and named references.
TOPICS = {
"climate change": {
"aliases": ["climate crisis", "changing climate", "climate change meaning", "climate change causes", "climate change effects"],
"keywords": ["climate", "long term weather", "global climate"],
"answer": """**Meaning:** Climate change means long-term changes in Earth's average temperatures and weather patterns. Climate has changed naturally in the past, but the rapid warming observed since the 20th century is mainly caused by human activities.

**Main causes:** Burning coal, oil and gas releases greenhouse gases such as carbon dioxide. Deforestation also adds to the problem because fewer trees are available to absorb carbon dioxide.

**Effects:** Rising average temperatures, melting glaciers and ice, sea-level rise, changing rainfall patterns, and increased risks from some heatwaves, droughts and heavy rainfall events.

**What can help:** Save energy, use cleaner energy, protect forests, reduce waste, and support climate-friendly decisions.""",
"sources": [("NASA – Climate Change", "https://climate.nasa.gov/"), ("IPCC – Reports", "https://www.ipcc.ch/reports/")]
},
"global warming": {
"aliases": ["what is global warming", "global warming causes", "global warming effects", "earth getting hotter"],
"keywords": ["warming", "hotter earth", "temperature rise"],
"answer": """Global warming is the long-term rise in Earth's average surface temperature. It is one important part of climate change.

The main cause of the recent warming is the increase in heat-trapping greenhouse gases from human activities, especially burning fossil fuels, deforestation and some industrial and agricultural activities.

Global warming contributes to melting ice, rising sea levels and changes in weather and ecosystems. It is different from a hot day: weather changes daily, while global warming describes a long-term trend.""",
"sources": [("NASA – The Causes of Climate Change", "https://climate.nasa.gov/causes/"), ("IPCC – Reports", "https://www.ipcc.ch/reports/")]
},
"greenhouse effect": {
"aliases": ["what is the greenhouse effect", "greenhouse gases", "how greenhouse effect works"],
"keywords": ["greenhouse", "carbon dioxide", "methane", "heat trapping"],
"answer": """The greenhouse effect is a natural process that keeps Earth warm enough for life. Sunlight warms Earth's surface. Earth then releases energy as infrared heat. Greenhouse gases in the atmosphere absorb and re-emit some of this heat, slowing its escape to space.

The problem is the **enhanced greenhouse effect**: human activities increase greenhouse gases, trapping more heat and warming the planet.

Important greenhouse gases include carbon dioxide, methane, nitrous oxide and water vapour.""",
"sources": [("NASA – The Greenhouse Effect", "https://climate.nasa.gov/faq/19/what-is-the-greenhouse-effect/"), ("NOAA – Greenhouse gases", "https://gml.noaa.gov/ccgg/")]
},
"air pollution": {
"aliases": ["what is air pollution", "causes of air pollution", "effects of air pollution", "dirty air"],
"keywords": ["air quality", "smoke", "vehicle emissions", "particulate matter"],
"answer": """Air pollution is the presence of harmful substances in the air at levels that can affect people, animals, plants or the environment.

**Sources:** Vehicle exhaust, factories, power stations, burning waste or fuels, construction dust and some natural events such as wildfires.

**Effects:** Air pollution can irritate the eyes and lungs, worsen breathing and heart conditions, harm crops and ecosystems, and reduce visibility.

**Prevention:** Use cleaner transport and energy, maintain vehicles, control industrial emissions, avoid open waste burning, and monitor air quality.""",
"sources": [("WHO – Air pollution", "https://www.who.int/health-topics/air-pollution"), ("UNEP – Air", "https://www.unep.org/explore-topics/air")]
},
"water pollution": {
"aliases": ["what is water pollution", "causes of water pollution", "effects of water pollution", "contaminated water"],
"keywords": ["dirty water", "water contamination", "polluted rivers"],
"answer": """Water pollution happens when harmful substances or organisms enter rivers, lakes, groundwater or oceans and make the water unsafe or damage aquatic ecosystems.

**Sources:** Untreated sewage, industrial discharge, agricultural fertilisers and pesticides, oil spills and plastic waste.

**Effects:** It can spread disease, reduce oxygen in water, harm aquatic organisms and make water unsafe for drinking or farming.

**Prevention:** Treat wastewater, dispose of chemicals properly, reduce plastic litter, use fertilisers carefully and protect riverbanks.""",
"sources": [("UNEP – Freshwater", "https://www.unep.org/explore-topics/water"), ("WHO – Drinking-water", "https://www.who.int/news-room/fact-sheets/detail/drinking-water")]
},
"soil pollution": {
"aliases": ["what is soil pollution", "causes of soil pollution", "land contamination"],
"keywords": ["contaminated soil", "soil chemicals", "land pollution"],
"answer": """Soil pollution is the contamination of soil by harmful chemicals, waste or other substances. It can come from improper waste disposal, industrial activities, mining, oil leaks and excessive or incorrect use of some agricultural chemicals.

Polluted soil can harm soil organisms, reduce soil quality, contaminate crops and allow pollutants to move into groundwater.

Prevention includes safe waste disposal, reducing harmful chemical use, treating industrial waste and cleaning contaminated land safely.""",
"sources": [("FAO – Soil pollution", "https://www.fao.org/global-soil-partnership/areas-of-work/soil-pollution/en/")]
},
"plastic pollution": {
"aliases": ["what is plastic pollution", "plastic waste", "microplastics", "effects of plastic pollution"],
"keywords": ["plastic", "microplastic", "single use plastic", "plastic bags"],
"answer": """Plastic pollution occurs when plastic products and fragments build up in the environment. Plastic can persist for a long time and may break into smaller pieces called microplastics.

Plastic waste can injure or be eaten by wildlife, block drains, pollute rivers and oceans, and affect habitats. Some plastic litter is carried from land into waterways.

**What helps:** Avoid unnecessary single-use items, reuse durable products, sort waste where recycling is available, and dispose of rubbish properly. Recycling is useful, but reducing and reusing are important too.""",
"sources": [("UNEP – Plastic pollution", "https://www.unep.org/plastic-pollution"), ("UNEP – Beat Plastic Pollution", "https://www.unep.org/interactives/beat-plastic-pollution/")]
},
"recycling": {
"aliases": ["what is recycling", "why is recycling important", "how recycling works"],
"keywords": ["recycle", "recyclable", "recycling benefits"],
"answer": """Recycling is the process of collecting and processing used materials so they can be made into new products.

It can reduce the amount of waste sent to landfill or dumped in the environment, save raw materials, and sometimes save energy compared with making products from new materials.

Not every material is recyclable everywhere. Items should be sorted according to local recycling rules and kept free from food or liquid contamination where required.""",
"sources": [("US EPA – Recycling basics", "https://www.epa.gov/recycle/recycling-basics")]
},
"3rs": {
"aliases": ["three rs", "reduce reuse recycle", "3 r principle", "3rs of waste management"],
"keywords": ["reduce", "reuse", "recycle"],
"answer": """The 3Rs are **Reduce, Reuse and Recycle**.

1. **Reduce:** Use fewer resources and avoid unnecessary products, packaging and waste.
2. **Reuse:** Use an item again, repair it, refill it or give it to someone who can use it.
3. **Recycle:** Process suitable used materials into new materials or products.

The order matters: reducing and reusing usually prevent waste before it is created, while recycling handles materials after use.""",
"sources": [("US EPA – Reducing and reusing basics", "https://www.epa.gov/recycle/reducing-and-reusing-basics")]
},
"deforestation": {
"aliases": ["what is deforestation", "causes of deforestation", "effects of deforestation", "forest clearing"],
"keywords": ["cutting trees", "forest loss", "clearing forests"],
"answer": """Deforestation is the long-term removal of forests, often to make land available for agriculture, roads, settlements, mining or other uses.

**Effects:** It destroys habitats, reduces biodiversity, can increase soil erosion and may release stored carbon into the atmosphere. It can also affect water cycles and local communities.

**Prevention:** Protect forests, manage them sustainably, restore damaged areas, reduce illegal logging and plan land use carefully.""",
"sources": [("FAO – Forests", "https://www.fao.org/forestry/en/"), ("UNEP – Forests", "https://www.unep.org/explore-topics/forests")]
},
"biodiversity": {
"aliases": ["what is biodiversity", "importance of biodiversity", "loss of biodiversity"],
"keywords": ["species diversity", "variety of life", "ecosystem diversity"],
"answer": """Biodiversity means the variety of life. It includes diversity within species, between species and among ecosystems.

Biodiversity supports food webs and ecosystem services such as pollination, soil formation, water purification and nutrient cycling. It also provides food, medicines, materials and cultural value.

It is threatened by habitat loss, pollution, overexploitation, invasive species and climate change. Protecting habitats and using natural resources sustainably helps conserve biodiversity.""",
"sources": [("Convention on Biological Diversity", "https://www.cbd.int/intro/"), ("IPBES", "https://www.ipbes.net/")]
},
"ecosystem": {
"aliases": ["what is an ecosystem", "components of ecosystem", "biotic and abiotic factors"],
"keywords": ["biotic", "abiotic", "living and nonliving", "habitat"],
"answer": """An ecosystem is a community of living organisms interacting with one another and with the non-living parts of their environment.

**Biotic components** are living things, such as plants, animals, fungi and microorganisms.

**Abiotic components** are non-living factors, such as sunlight, water, air, soil and temperature.

Energy flows through ecosystems, while materials such as water and nutrients are recycled.""",
"sources": [("US National Park Service – Ecosystems", "https://www.nps.gov/subjects/nnlandmarks/ecosystems.htm"), ("OpenStax Biology 2e", "https://openstax.org/details/books/biology-2e")]
},
"food chain": {
"aliases": ["what is a food chain", "food chain example", "producer consumer decomposer"],
"keywords": ["food web", "trophic level", "producer", "consumer", "decomposer"],
"answer": """A food chain shows one pathway through which energy and nutrients pass as organisms eat one another.

A simple example is **grass → grasshopper → frog → snake**.

- **Producer:** Usually a green plant that makes its own food using sunlight.
- **Consumer:** An organism that gets energy by eating other organisms.
- **Decomposer:** Organisms such as fungi and bacteria that break down dead material and return nutrients to the environment.

Real ecosystems usually contain many connected food chains called food webs.""",
"sources": [("OpenStax Biology 2e – Ecology", "https://openstax.org/details/books/biology-2e")]
},
"renewable energy": {
"aliases": ["what is renewable energy", "examples of renewable energy", "renewable sources"],
"keywords": ["solar", "wind", "hydropower", "geothermal", "renewable"],
"answer": """Renewable energy comes from sources that are naturally replenished on a human timescale. Examples include sunlight, wind, flowing water, geothermal heat and sustainably managed biomass.

Renewable energy can reduce greenhouse-gas emissions and air pollution compared with many fossil-fuel systems. However, each technology has environmental and practical considerations, such as land use, effects on rivers, materials and the need to balance supply and demand.""",
"sources": [("International Energy Agency – Renewables", "https://www.iea.org/energy-system/renewables"), ("IRENA", "https://www.irena.org/")]
},
"fossil fuels": {
"aliases": ["what are fossil fuels", "examples of fossil fuels", "coal oil natural gas"],
"keywords": ["coal", "petroleum", "natural gas", "non renewable"],
"answer": """Fossil fuels are energy sources formed from ancient organic matter over millions of years. The main examples are coal, oil and natural gas.

They are non-renewable because they take far longer to form than people take to use them. Burning fossil fuels releases carbon dioxide and air pollutants. This contributes to climate change and can harm human health.

Using energy more efficiently and replacing fossil fuels with lower-emission energy sources can reduce these impacts.""",
"sources": [("US EIA – Nonrenewable energy", "https://www.eia.gov/energyexplained/what-is-energy/sources-of-energy.php"), ("IPCC – Reports", "https://www.ipcc.ch/reports/")]
},
"solar energy": {
"aliases": ["what is solar energy", "how solar panels work", "solar power"],
"keywords": ["sunlight", "solar panel", "photovoltaic"],
"answer": """Solar energy is energy from sunlight. Solar photovoltaic (PV) panels convert light directly into electricity. Solar thermal systems use sunlight to produce heat.

Solar energy is renewable and produces no direct greenhouse-gas emissions while generating electricity. Its output depends on sunlight, weather, location and time of day, so storage or other electricity sources may be needed when sunlight is unavailable.""",
"sources": [("US Department of Energy – Solar energy", "https://www.energy.gov/eere/solar/how-does-solar-work")]
},
"wind energy": {
"aliases": ["what is wind energy", "how wind turbines work", "wind power"],
"keywords": ["wind turbine", "wind farm"],
"answer": """Wind energy uses moving air to turn turbine blades. The turbine drives a generator that produces electricity.

Wind is renewable and turbines do not burn fuel while generating electricity. However, wind power depends on wind conditions, and projects need careful siting to consider wildlife, people, landscapes and connections to the electricity grid.""",
"sources": [("US Department of Energy – Wind energy", "https://www.energy.gov/eere/wind/how-do-wind-turbines-work")]
},
"hydropower": {
"aliases": ["what is hydropower", "hydroelectricity", "hydroelectric power"],
"keywords": ["water power", "dam", "river electricity"],
"answer": """Hydropower generates electricity using the energy of moving or falling water. In many systems, flowing water turns a turbine connected to a generator.

Hydropower can provide low-carbon electricity and, in some systems, flexible power. Dams and river projects can also change river flow, affect fish migration, sediment movement and nearby communities. Environmental planning is important.""",
"sources": [("International Energy Agency – Hydropower", "https://www.iea.org/energy-system/renewables/hydropower")]
},
"ozone layer": {
"aliases": ["what is the ozone layer", "ozone depletion", "ozone hole"],
"keywords": ["ozone", "ultraviolet", "uv radiation", "cfc"],
"answer": """The ozone layer is a region of the stratosphere containing relatively high concentrations of ozone. It absorbs much of the Sun's harmful ultraviolet (UV) radiation.

Certain human-made chemicals, especially older ozone-depleting substances such as CFCs, damage stratospheric ozone. The Montreal Protocol controls many of these substances and has helped the ozone layer recover gradually.

The ozone layer is different from ground-level ozone, which is an air pollutant.""",
"sources": [("NASA – Ozone Watch", "https://ozonewatch.gsfc.nasa.gov/"), ("UNEP – Ozone Secretariat", "https://ozone.unep.org/")]
},
"acid rain": {
"aliases": ["what is acid rain", "causes of acid rain", "effects of acid rain"],
"keywords": ["sulfur dioxide", "nitrogen oxides", "acid deposition"],
"answer": """Acid rain is precipitation that is more acidic than normal. It forms when sulfur dioxide (SO₂) and nitrogen oxides (NOₓ) react in the atmosphere and produce acids.

These gases mainly come from burning fossil fuels in power stations, industries and vehicles. Acid deposition can make lakes and soils more acidic, damage plants and affect buildings.

Reducing emissions of sulfur dioxide and nitrogen oxides helps prevent acid rain.""",
"sources": [("US EPA – What is Acid Rain?", "https://www.epa.gov/acidrain/what-acid-rain")]
},
"composting": {
"aliases": ["what is composting", "how to make compost", "compost benefits"],
"keywords": ["organic waste", "food scraps", "decomposing"],
"answer": """Composting is the controlled breakdown of organic materials, such as fruit and vegetable scraps and dry leaves, into a soil-like material called compost.

Compost can add organic matter to soil and improve its structure and water-holding ability. A balanced compost pile needs suitable moisture and air, along with a mix of materials.

Follow local guidance about what can be composted. Meat, dairy and oily foods may attract pests or cause problems in simple home compost systems.""",
"sources": [("US EPA – Composting at home", "https://www.epa.gov/recycle/composting-home")]
},
"water conservation": {
"aliases": ["how to save water", "water conservation meaning", "ways to conserve water"],
"keywords": ["save water", "water saving", "water wastage"],
"answer": """Water conservation means using water carefully and avoiding unnecessary waste.

Practical actions include fixing leaks, turning off taps when water is not needed, using water-efficient fixtures, collecting rainwater where safe and permitted, and protecting rivers and watersheds.

Conserving water also saves energy because treating and pumping water requires energy. Water should always be kept clean and safe for drinking.""",
"sources": [("UN-Water", "https://www.unwater.org/"), ("US EPA – WaterSense", "https://www.epa.gov/watersense")]
},
"carbon footprint": {
"aliases": ["what is a carbon footprint", "reduce carbon footprint", "personal carbon footprint"],
"keywords": ["emissions", "carbon dioxide equivalent", "climate impact"],
"answer": """A carbon footprint is the total greenhouse-gas emissions associated with a person, product, activity, organisation or event, usually expressed as carbon dioxide equivalent (CO₂e).

It can include direct emissions, such as fuel burned in a vehicle, and indirect emissions, such as emissions from producing electricity or making goods.

Possible ways to reduce a footprint include saving energy, choosing lower-emission transport when practical, reducing food and material waste, and using products for longer.""",
"sources": [("GHG Protocol", "https://ghgprotocol.org/"), ("UN ActNow", "https://www.un.org/en/actnow")]
},
"sustainable development": {
"aliases": ["what is sustainable development", "meaning of sustainability", "sustainable development goals"],
"keywords": ["sustainability", "future generations", "sdgs"],
"answer": """Sustainable development means meeting the needs of the present without compromising the ability of future generations to meet their own needs.

It involves balancing environmental protection, social well-being and economic development. Examples include using resources efficiently, protecting ecosystems, improving access to education and healthcare, and developing cleaner energy.

The United Nations Sustainable Development Goals provide a shared framework for addressing global challenges.""",
"sources": [("United Nations – Sustainable Development", "https://sdgs.un.org/goals"), ("UN – Our Common Future", "https://sustainabledevelopment.un.org/content/documents/5987our-common-future.pdf")]
},
"endangered species": {
"aliases": ["what is an endangered species", "why animals become endangered", "protect endangered animals"],
"keywords": ["threatened species", "extinction", "wildlife protection"],
"answer": """An endangered species is a species facing a very high risk of extinction in the wild. The IUCN Red List uses categories to assess extinction risk; 'Endangered' is one of its threatened categories.

Species can become endangered because of habitat loss, overhunting or overfishing, pollution, invasive species, disease and climate change.

Conservation actions include protecting habitats, enforcing wildlife laws, restoring ecosystems and supporting responsible community-based conservation.""",
"sources": [("IUCN Red List", "https://www.iucnredlist.org/"), ("Convention on Biological Diversity", "https://www.cbd.int/")]
},
"soil erosion": {
"aliases": ["what is soil erosion", "causes of soil erosion", "prevent soil erosion"],
"keywords": ["topsoil", "erosion", "land degradation"],
"answer": """Soil erosion is the removal of topsoil by water, wind or other forces. It can happen naturally, but activities such as deforestation, overgrazing and poorly managed farming can increase it.

Soil erosion reduces fertile soil, can damage farmland and may carry sediment into rivers and reservoirs.

Ways to reduce erosion include keeping vegetation cover, planting trees, using terraces on suitable slopes, maintaining ground cover and managing grazing carefully.""",
"sources": [("FAO – Soil", "https://www.fao.org/soils-portal/en/")]
},
"glaciers": {
"aliases": ["what are glaciers", "glacier melting", "why glaciers are melting"],
"keywords": ["ice melt", "mountain ice", "glacial retreat"],
"answer": """A glacier is a large, long-lasting mass of ice that forms on land when snow builds up over many years and compresses into ice.

Many glaciers around the world are losing mass because of rising air temperatures. Glacier loss contributes to sea-level rise and can change the timing and amount of water flowing into rivers.

In high mountain regions, glacier and snow changes can affect water supplies and increase some hazards. Local risks need to be assessed using scientific monitoring.""",
"sources": [("NASA – Ice and climate", "https://climate.nasa.gov/"), ("World Glacier Monitoring Service", "https://wgms.ch/")]
},
"bhutan environment": {
"aliases": ["environment of bhutan", "bhutan environmental conservation", "bhutan and climate change"],
"keywords": ["bhutan", "gross national happiness", "forest cover", "national environment commission"],
"answer": """Bhutan is known for its rich forests, rivers, mountains and biodiversity. Environmental conservation is an important part of the country's development approach.

The Constitution of Bhutan directs the country to maintain at least 60% of its total land under forest cover for all time. Bhutan is also exposed to climate-related risks, including changing rainfall, glacier and glacial-lake hazards, floods and landslides.

Protecting watersheds, forests and wildlife, managing waste, and preparing for climate risks are important for Bhutan's sustainable future. For current national policies and data, consult Bhutan's official agencies rather than relying on an undated statistic.""",
"sources": [("National Environment Commission of Bhutan", "https://nec.gov.bt/"), ("Constitution of the Kingdom of Bhutan – official portal", "https://www.nationalcouncil.bt/"), ("UNDP Bhutan", "https://www.undp.org/bhutan")]
},
"climate change in bhutan": {
"aliases": ["bhutan climate change", "effects of global warming in bhutan", "climate risks in bhutan"],
"keywords": ["bhutan", "glacial lake", "glacier", "landslide", "flood"],
"answer": """Climate change can affect Bhutan through changes in temperature, rainfall, snow and glaciers. Potential concerns include glacial lake outburst floods, flash floods, landslides, changing water availability and impacts on farming and ecosystems.

The exact level of risk differs by place and changes over time. Local assessments and official early-warning information are important. Communities can prepare through risk mapping, safe land-use planning, resilient infrastructure, ecosystem protection and disaster preparedness.""",
"sources": [("National Environment Commission of Bhutan", "https://nec.gov.bt/"), ("UNDP Bhutan", "https://www.undp.org/bhutan"), ("IPCC – Reports", "https://www.ipcc.ch/reports/")]
},
"forest conservation in bhutan": {
"aliases": ["bhutan forest conservation", "60 percent forest cover bhutan", "why bhutan protects forests"],
"keywords": ["bhutan", "forest", "constitution", "60 percent"],
"answer": """Bhutan's Constitution directs the country to maintain at least 60% of its total land under forest cover for all time. Forests help store carbon, protect soil and watersheds, provide habitat for wildlife and support people's livelihoods.

Forest conservation also involves preventing forest fires, managing resources sustainably, protecting biodiversity and involving local communities. For the latest forest statistics, use current official Bhutanese reports because figures depend on the survey year and definition used.""",
"sources": [("National Environment Commission of Bhutan", "https://nec.gov.bt/"), ("FAO – Global Forest Resources Assessment", "https://www.fao.org/forest-resources-assessment/en/")]
},
}

def normalize(text):
    text = text.lower().replace("’", "'")
    text = re.sub(r"[^a-z0-9\s]", " ", text)
    return re.sub(r"\s+", " ", text).strip()

def find_topic(question):
    q = normalize(question)
    if not q:
        return None, 0
    best_key, best_score = None, 0
    words = set(q.split())
    for key, item in TOPICS.items():
        phrases = [key] + item.get("aliases", [])
        score = 0
        # Strong match for a complete known phrase.
        for phrase in phrases:
            p = normalize(phrase)
            if p and p in q:
                score = max(score, 10 + len(p.split()))
        # Keyword matching is deliberately conservative.
        matched = {normalize(k) for k in item.get("keywords", []) if normalize(k) in words}
        if matched:
            score = max(score, len(matched) * 2)
        # Topic title words count only when a meaningful multiword title is present.
        title_words = set(normalize(key).split())
        if len(title_words) > 1 and title_words.issubset(words):
            score = max(score, 12)
        if score > best_score:
            best_key, best_score = key, score
    return best_key, best_score

def show_answer(question):
    topic, score = find_topic(question)
    if not topic or score < 5:
        st.warning("I don't have a verified answer for that question yet.")
        st.write("Try asking about a topic in the Topic Library, or use one of the suggested questions below.")
        st.caption("EcoBot will not guess when it cannot confidently match your question.")
        return
    item = TOPICS[topic]
    st.markdown(f"### 🌿 {topic.title()}")
    st.markdown(item["answer"])
    st.markdown("**Sources for further reading**")
    for label, url in item["sources"]:
        st.markdown(f"- [{label}]({url})")

st.markdown("""
<div class="hero">
  <h1>🌿 EcoBot</h1>
  <p>Your environmental learning companion — ask, explore and take action for our planet.</p>
</div>
""", unsafe_allow_html=True)

st.info("Educational chatbot • Curated answers • Trusted reading links • No AI service or API key")

tab_chat, tab_library, tab_quiz, tab_about = st.tabs(["💬 Chat", "📚 Topic Library", "🧠 Eco Quiz", "ℹ️ About"])

with tab_chat:
    st.subheader("Ask EcoBot")
    st.write("Ask a question in your own words. EcoBot matches it to a reviewed topic guide.")
    if "messages" not in st.session_state:
        st.session_state.messages = []
    for msg in st.session_state.messages:
        with st.chat_message(msg["role"]):
            if msg["role"] == "user":
                st.markdown(msg["content"])
            else:
                st.markdown(msg["content"], unsafe_allow_html=True)
    prompt = st.chat_input("Ask an environmental question...")
    if prompt:
        st.session_state.messages.append({"role": "user", "content": prompt})
        with st.chat_message("user"):
            st.markdown(prompt)
        with st.chat_message("assistant"):
            topic, score = find_topic(prompt)
            if topic and score >= 5:
                item = TOPICS[topic]
                st.markdown(f"### 🌿 {topic.title()}")
                st.markdown(item["answer"])
                st.markdown("**Sources for further reading**")
                for label, url in item["sources"]:
                    st.markdown(f"- [{label}]({url})")
                saved = f"### 🌿 {topic.title()}\n\n{item['answer']}\n\n**Sources for further reading**\n" + "\n".join(f"- [{label}]({url})" for label,url in item["sources"])
            else:
                st.warning("I don't have a verified answer for that question yet.")
                st.write("Try a topic from the Topic Library. EcoBot will not guess when it cannot confidently match your question.")
                saved = "I don't have a verified answer for that question yet. Try a topic from the Topic Library."
        st.session_state.messages.append({"role": "assistant", "content": saved})
    c1, c2 = st.columns(2)
    with c1:
        if st.button("Clear chat", use_container_width=True):
            st.session_state.messages = []
            st.rerun()
    with c2:
        if st.button("Show sample questions", use_container_width=True):
            st.session_state.show_samples = not st.session_state.get("show_samples", False)
    if st.session_state.get("show_samples", False):
        st.markdown("**Try asking:**")
        samples = ["What is climate change?", "How does the greenhouse effect work?", "What are the 3Rs?", "Why is biodiversity important?", "How can Bhutan protect its forests?"]
        for sample in samples:
            if st.button(sample, key="sample_"+sample, use_container_width=True):
                st.session_state.messages.append({"role":"user","content":sample})
                st.rerun()

with tab_library:
    st.subheader("Explore environmental topics")
    search = st.text_input("Find a topic", placeholder="Try climate, forests, water...")
    topics = sorted(TOPICS.keys())
    if search:
        s = normalize(search)
        topics = [t for t in topics if s in normalize(t) or any(s in normalize(a) for a in TOPICS[t]["aliases"])]
    st.caption(f"{len(topics)} topic guides")
    for topic in topics:
        with st.expander(topic.title()):
            st.markdown(TOPICS[topic]["answer"])
            st.markdown("**Sources**")
            for label, url in TOPICS[topic]["sources"]:
                st.markdown(f"- [{label}]({url})")

with tab_quiz:
    st.subheader("Eco Quiz")
    questions = [
        ("Which gas is a major driver of recent human-caused global warming?", ["Oxygen", "Carbon dioxide", "Helium"], 1, "Carbon dioxide is released in large amounts when fossil fuels are burned."),
        ("What do the 3Rs stand for?", ["Reduce, Reuse, Recycle", "Read, Repeat, Remember", "Repair, Remove, Replace"], 0, "Reducing and reusing prevent waste before recycling."),
        ("What is biodiversity?", ["Only the number of trees", "The variety of life", "The amount of rainfall"], 1, "Biodiversity includes variation within species, between species and among ecosystems."),
        ("Which is a renewable energy source?", ["Coal", "Oil", "Sunlight"], 2, "Sunlight is naturally replenished."),
        ("What does a producer usually do in a food chain?", ["Makes its own food", "Eats only animals", "Breaks down rocks"], 0, "Green plants are producers because they use sunlight to make food.")
    ]
    if "quiz_answers" not in st.session_state:
        st.session_state.quiz_answers = {}
    for i, (q, opts, correct, explanation) in enumerate(questions):
        st.markdown(f"**{i+1}. {q}**")
        st.session_state.quiz_answers[i] = st.radio("Choose one:", opts, key=f"quiz_{i}", index=None, label_visibility="collapsed")
    if st.button("Check my answers"):
        score = 0
        for i, (_, opts, correct, explanation) in enumerate(questions):
            selected = st.session_state.quiz_answers.get(i)
            if selected == opts[correct]:
                score += 1
                st.success(f"Question {i+1}: Correct! {explanation}")
            else:
                st.info(f"Question {i+1}: Correct answer: **{opts[correct]}**. {explanation}")
        st.markdown(f"### Your score: {score}/{len(questions)}")

with tab_about:
    st.subheader("About EcoBot")
    st.write("EcoBot is a retrieval-based educational chatbot. It uses a collection of prepared topic explanations and matches questions to those topics.")
    st.write("It does not use generative AI, does not send questions to an AI service, and does not need an API key.")
    st.write("Answers are designed for school-level learning. The source links help users read more and verify information.")
    st.warning("Limitations: EcoBot only answers topics included in its knowledge library. It can misunderstand unusual wording. For important decisions or the newest statistics, check the original source and its publication date.")
    st.markdown("**Knowledge library:** " + str(len(TOPICS)) + " topic guides.")
    st.markdown("**Main reference organisations:** NASA, IPCC, WHO, UNEP, FAO, IUCN, UN agencies, US EPA and Bhutan's National Environment Commission.")

st.divider()
st.caption("EcoBot • Learn responsibly. Protect our planet. 🌍")
